THE BIG BOYS — CURRENT VERSION

Updated website:
- Removed the inbox.
- Added direct email messaging to mr8772320@gmail.com.
- Visitors sign up with full name, email, date of birth and picture.
- Added message field.
- Added Telegram and Discord buttons.
- Responsive dark sports-community design.

The form uses FormSubmit. The first submission may require an activation/confirmation email.
Documentation: https://formsubmit.co/documentation

The website is not online until you upload index.html to a web host.
